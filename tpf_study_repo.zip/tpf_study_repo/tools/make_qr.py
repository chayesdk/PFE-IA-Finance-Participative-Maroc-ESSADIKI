"""Generate a QR code (PNG) for a link.
Usage:  python tools/make_qr.py "https://github.com/<user>/<repo>" qr_github.png
        python tools/make_qr.py "https://drive.google.com/..."      qr_drive.png
Requires:  pip install "qrcode[pil]"
"""
import sys, qrcode
from qrcode.constants import ERROR_CORRECT_H

url = sys.argv[1]
out = sys.argv[2] if len(sys.argv) > 2 else "qr.png"
qr = qrcode.QRCode(error_correction=ERROR_CORRECT_H, box_size=12, border=4)   # H = 30% error correction
qr.add_data(url); qr.make(fit=True)
qr.make_image(fill_color="black", back_color="white").save(out)
print("saved", out, "->", url)
