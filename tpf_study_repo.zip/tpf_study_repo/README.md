# AI for forecasting participatory financing in Morocco: study code

Code of the master's thesis **"Artificial intelligence in financial forecasting and participatory data analysis"**
(Moroccan participatory banks, monthly data, October 2018 - June 2026, 93 observations).

> **Everything that produced the results of the thesis is in one file: [`src/tpf_study.py`](src/tpf_study.py).**

## What the code does

| Thesis step | Function | Output |
| --- | --- | --- |
| 1 Descriptive statistics | `eda()` | `eda_tables.xlsx` (01), figures 1-2 |
| 2 Stationarity (ADF) | `eda()` | `eda_tables.xlsx` (02), figures 3-4 |
| 3 Outliers (IQR rule) | `iqr_filter()`, `eda()` | sheet 03, figures 5-6 |
| 4 Correlation, VIF, PCA, variable selection, bivariate relations | `eda()` | sheets 04-05, figures 7-9 and 26 |
| 5 Standardisation and split | `make_split()`, `run()` | figure 10 |
| 6 Synthetic data (VAE, cGAN) and quality | `train_vae()`, `train_cgan()`, `synth_quality()` | figures 12-14 |
| 7-8 Eight models x 3 training sets, metrics | `make_model()`, `fit_predict()`, `metrics()`, `run()` | `results_tables.xlsx`, figures 15-17 |
| 9 Diagnostics, learning curve, SHAP | `analyze()` | figures 18-23 |
| 10 Comparison with LR and Poisson/PPML, Diebold-Mariano | `analyze()` | sheet 10_DM, figure 24 |
| 11 Sensitivity (no removal, chronological split, 17 variables) | `run_all()`, `analyze()` | figure 25 |
| 12 Hypotheses H1-H5 (Wilcoxon, Friedman, regressions) | `analyze()`, `hypotheses()` | printed tables |

The eight models: Linear Regression (LR), Decision Tree (DT), Random Forest (RF), XGBoost (XGB), MLP, SVR, Gradient Boosting (GBR),
Extra Trees (ET), with the hyper-parameters retained in the thesis. Benchmark: Poisson/PPML.
Metrics: MAE, MSE, RMSE, R2, MAPE, Explained Variance, Median AE.

## Installation

```bash
python -m venv venv && source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Usage

Put the Excel file in `data/` (see `data/README.md`), then:

```bash
python src/tpf_study.py eda                    # steps 1-5 (about 1 minute)
python src/tpf_study.py run_all --seeds 10     # 4 scenarios x repetitions (about 20 minutes on one CPU)
python src/tpf_study.py analyze                # tables, tests, SHAP, figures (about 2 minutes)
python src/tpf_study.py hypotheses | tee results/hypotheses_results.txt     # H1-H3
python src/tpf_study.py all                    # all of the above
```

Options: `--data`, `--out` (default `results/`), `--work` (default `work/`), `--scenario`, `--featset`, `--seeds`.

## Reproducibility

* All random operations are seeded; with the versions in `requirements.txt` the numbers are reproduced exactly
  (the tables in `results/` were produced with 10 repetitions).
* The synthetic data are generated from the **training set only** in each repetition (no leakage from the test set).
* Other library versions may change the last decimals.

## Repository tree

```
src/tpf_study.py      complete code
tools/make_qr.py      QR code for the links of the thesis
data/                 data folder (see data/README.md)
results/              tables and figures produced by the code
requirements.txt  LICENSE  CITATION.cff
```

## Citation

See `CITATION.cff`. Licence: MIT.

---

## بالعربية

هذا المستودع يضم الكود الكامل للدراسة: **الذكاء الاصطناعي في التنبؤ المالي وتحليل البيانات التشاركية** (حالة البنوك التشاركية المغربية، بيانات شهرية من أكتوبر 2018 إلى يونيو 2026).
كل ما أنتج نتائج الأطروحة موجود في ملف واحد: `src/tpf_study.py`، وتوضح الجداول أعلاه الدالة المقابلة لكل خطوة في الأطروحة.
للتشغيل: ثبّتي المكتبات من `requirements.txt`، وضعي ملف البيانات في `data/`، ثم نفّذي `python src/tpf_study.py all`.
